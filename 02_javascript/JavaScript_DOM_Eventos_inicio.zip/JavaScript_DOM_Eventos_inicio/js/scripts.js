//scripts.js

//Seleccionar codigo HTML

//console.log('Funciona correctamente');

// querySelector, retorna ninguno o hasta un elemento
// funciona igual que css 
// .clase para clases
// #elementoId para el id


// const heading = document.querySelector('h2'); // 0 o 1 elemento
// console.log(heading);

// se recomienda el uso de los id para trabajar con javascript

// const heading = document.querySelector('#heading'); // 0 o 1 elemento
// console.log(heading);

const heading = document.querySelector('.header__texto h2'); // 0 o 1 elemento
//console.log(heading);
heading.textContent = 'Nuevo Heading';
heading.classList.add('nueva-clase');
console.log(heading);
// si te equivocas en el selector el valor de retorno es null
// todo lo que se tiene en html puede ser manipulado por medio de javascript


// querySelectorAll, retorna de cero hasta todos los elementos que 
// concuerden con el selector tipo css que le pasemos a la función de 
// query selector

const enlaces = document.querySelectorAll('.navegacion a');
console.log(enlaces);
//accediendo al primer enlace
console.log(enlaces[0]);

enlaces[0].textContent= 'Nuevo texto para enlace';

// otra forma de hacerlo
// document.querySelectorAll('.navegacion a')[0].textContent= 'Otro Nuevo texto para enlace';
// enlaces[0].href = 'http://google.com';
enlaces[0].classList.add('nueva-clase');
// enlaces[0].classList.remove('navegacion__enlace');

// getElementById  //es similar en cuanto a las operaciones de los dos anteriores
const heading2 = document.getElementById('heading');
console.log(heading2)

// ##### CREAR CODIGO HTML DESDE JAVASCRIPT

// Generar nuevo enlace
//const nuevoEnlace = document.createElement('h1');
// const nuevoEnlace = document.createElement('H1'); // se recomienda usar mayusculas
const nuevoEnlace = document.createElement('A'); // se recomienda usar mayusculas

//un enlace se ve de esta forma
{/* <a href="nosotros.html" class="nuevo-enlace">Nosotros</a> */}

// hay varias cosas por hacer

//agregar el href
nuevoEnlace.href = 'nuevo-enlace.html';
//agregar el texto
nuevoEnlace.textContent = 'Un nuevo enlace'
//agregar la clase
nuevoEnlace.classList.add('navegacion__enlace');

// Agregarlo al documento

// para el elemplo escribir en la consola
// document.querySelector('.navegacion'); // va a resaltar la primer navegacion que encuentra
const navegacion = document.querySelector('.navegacion');
navegacion.appendChild(nuevoEnlace);

console.log(nuevoEnlace);


// ### EVENTOS

// Hay eventos que se generan por el usuario y hay eventos que se 
// generan automaticamente en el sitio web

// console.log(1);

//uno de los eventos que se generan es cuando la pagina está lista

//window es un nivel más alto de document
// window.setTimeout

//esperar hasta que la ventana esté lista
// a esta forma de programación se le conoce como callback

// load espera a que el JS y los archivos que dependen del HTML estén listos
// incluye imagenes y los estilos
//window.addEventListener('load', function(){ 
    // console.log(2);                                        
window.addEventListener('load', imprimir); 

// otra forma de hacerlo es 
// probar moviendo este codigo arriva de addEventListener
window.onload = function() {
    // console.log(3);
}

// un tercer evento
// solo espera a que se descarga el HTML, pero no espera css o imagenes
// este es más rápido 
document.addEventListener('DOMContentLoaded', function(){
    // console.log(4)
})

// console.log(5);

// las funciones que registramos como callback tambien pueden 
// ser funciones aparte, y se usa si se tienen muchas funciones 
// separadas

function imprimir(){
    // console.log(2);
}


window.onscroll = function(){
    // console.log('scrolling...');
}

// ### SELECCIONAR ELEMENTOS Y ASOCIARLES UN EVENTO
const btnEnviar = document.querySelector('.boton--primario');
// btnEnviar.addEventListener('click', function(evento){ //comentar cuando se explique submit de formulario

// // btnEnviar.addEventListener('click', function(evento){  // agregar despues de la primer prueba
//     // console.log(evento); // agregar despues de la primer prueba //analizar la información en la consola
//     evento.preventDefault(); // agregar despues de la primer prueba
//                             // usuarlmente se usa el prevent default para validar un formulario y luego enviarlo
//     console.log('Enviando Formulario');
//     // lo hace  uyt rapido porque el comportamiento normal es 
//     // enviar la información a otro archivo dentro del servidor
//     // y debería ser especificado en la etiqueta form
// })

// ### EVENTOS DE LOS INPUTS Y TEXTAREA

// El id de un campo de texto para cuando escribimos
const nombre = document.querySelector('#nombre');

// nombre.addEventListener('change', function(){ // se ejecuta hasta cuando se deselecciona el control
//      console.log('Escribiendo...')
// })

// para una validación más en tiempo real
// nombre.addEventListener('input', function(){ // se ejecuta hasta cuando se deselecciona el control
//     console.log('Escribiendo...')
// })

// como leer lo que el usuario escribe, hay que pasarle un evento
// nombre.addEventListener('input', function(e){ // se ejecuta hasta cuando se deselecciona el control
//     console.log(e);
// })

// mostrar agregar en el html en la linea 48, despues de id="nombre", value="HOLA MUNDO"
nombre.addEventListener('input', function(e){ // se ejecuta hasta cuando se deselecciona el control
    console.log(e.target.value);
})

// luego quitar la linea de value que agregamos

// El id de un campo de texto para cuando escribimos
const email = document.querySelector('#email');
const mensaje = document.querySelector('#mensaje');


email.addEventListener('input', function(e){ // se ejecuta hasta cuando se deselecciona el control
    console.log(e.target.value);
});

mensaje.addEventListener('input', function(e){ // se ejecuta hasta cuando se deselecciona el control
    console.log(e.target.value);
});

// como las tres funciones hacen lo mismo, entonces hay que crear la funcion leer
function leerTexto(e){
    console.log(e.target.value);
}

// quedarian de la siguiente forma, y hay que comentar los anteriores
mensaje.addEventListener('input', leerTexto);
nombre.addEventListener('input', leerTexto);
email.addEventListener('input', leerTexto);


// validación de los mensajes, este objeto ponerlo antes de las funciones de validación
// este va a ser un objeto global 
const datos = {
    nombre: '',
    email: '',
    mensaje : ''
}

function leerTexto(e){
    datos[e.target.id] = e.target.value;

    console.log(datos);
}

// ### ENVENTOS DE FORMULARIO
// eventos del submit

// el evento submit tiene que asociarse siempre a un formulario y tiene que tener un elemnto de tipo submit

const formulario = document.querySelector('.formulario');
formulario.addEventListener('submit',function(evento){
    evento.preventDefault();

    // validar el formulario

    // usando e objeto global
    const {nombre, email, mensaje} = datos;

    console.log(nombre);
    console.log(email);
    console.log(mensaje);

    if(nombre === '' || email === '' || mensaje === ''){
        // console.log('El nombre o email están vacíos');
        // console.log('Todos los campos son obligatorios');
        mostrarError('Todos los campos son obligatorios');

        return; // corta la ejecución del código
    }
    
    console.log('Enviando Formulario');


    // Crear la alerta de Enviar correctamente
    mostrarMensaje('Mensaje enviado correctamente');
})

// todos los query selector deben ir juntos al inicio del código, todas las variables en la parte superior

// Despues todos los even listeners

// y despues algunas funciones.

// Muestra una alerta de que se envio correctamente
function mostrarMensaje(mensaje) {
    const alerta = document.createElement('P');
    alerta.textContent= mensaje;
    alerta.classList.add('correcto');

    formulario.appendChild(alerta);


    // Desaparezca despues de 5 segundos
    setTimeout(() => {
        alerta.remove();
    }, 5000)

}

// en el css 
// .correcto {
//     background-color: rgb(74, 185, 0);
//     text-align: center;
//     padding: 1rem;
//     color: var(--blanco);
//     text-transform: uppercase;
// }


// Muestra un error en pantalla
function mostrarError(mensaje) {
    // console.log(mensaje);
    const error = document.createElement('P');
    error.textContent = mensaje;
    error.classList.add('error');

    // console.log(error);
    formulario.appendChild(error);

    // Desaparezca despues de 5 segundos
    setTimeout(() => {
        error.remove();
    }, 5000)

}

// abrir la hoja de estilos
// desplazarse debajo de Contacto y agregar

// .error {
//     background-color: rgb(185, 0, 0);
//     text-align: center;
//     padding: 1rem;
//     color: var(--blanco);
//     text-transform: uppercase;
// }




