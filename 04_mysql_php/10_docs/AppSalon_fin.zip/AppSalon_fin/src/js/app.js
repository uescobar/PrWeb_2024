// se agrega en la seccion 9
let pagina = 1; //variable global

//Se agrega en la seccion 13
const cita = {
    nombre: '',
    fecha: '', 
    hora: '',
    servicios: []
}

document.addEventListener('DOMContentLoaded', function() {
    iniciarApp();
});

function iniciarApp(){
    //consultarDB();

    mostrarServicios();

    //Seccion 9
    // Resalta el div actual según el tab al que se presiona
    mostrarSeccion();


    // Oculta o muestra una sección según el tab al que se presiona
    cambiarSeccion();

    // Paginación siguiente y anterior
    paginaSiguiente();

    paginaAnterior();

    // Comprueba la página actual para ocultar o mostrar la paginación
    botonesPaginador();

    // Se agrega en la sección 13
    // Muestra el resumen de la cita (o mensaje de error en caso de no pasar la validación)
    mostrarResumen();

    // Se agrega en la sección 15
    // Almacena el nombre de la cita en el objeto
    nombreCita();

    // Se agrega en la sección 17
    // Almacena la fecha de la cita en el objeto
    fechaCita();

    // Se agrega en la sección 18
    // deshabilita los dias pasados
    deshabilitarFechaAnterior();

    // Se agrega en la sección 19
    // Almacenar la hora de la cita en el objeto
    horaCita();
    
}

function mostrarSeccion(){


    // SE AGREGA EN PASO 11
    // Eliminar mostrar-seccion de la seccion anterior  
    const seccionAnterior = document.querySelector('.mostrar-seccion');
    if( seccionAnterior ){
        seccionAnterior.classList.remove('mostrar-seccion');
    }

    const seccionActual = document.querySelector(`#paso-${pagina}`);
    seccionActual.classList.add('mostrar-seccion');

    // SE AGREGA EN PASO 11
    const tabAnterior = document.querySelector('.tabs .actual');
    if(tabAnterior){
        tabAnterior.classList.remove('actual');
    }
    // Resalta el tab actual
    const tab = document.querySelector(`[data-paso="${pagina}"]`); //se usan corchetes porque es una propiedad y no una clase
    tab.classList.add('actual'); 
}

function cambiarSeccion(){
    const enlaces = document.querySelectorAll('.tabs button');

    enlaces.forEach(enlace => {
        enlace.addEventListener('click', e => {
            e.preventDefault();

            //console.log('Click en botón');
            //console.log(e.target.dataset.paso);
            pagina = parseInt(e.target.dataset.paso); // se tiene que cambiar porque era un string
            
            // Eliminar mostrar-seccion de la seccion anterior
            //- document.querySelector('.mostrar-seccion').classList.remove('mostrar-seccion');

            



            //console.log(pagina);

            // Agrega  mostrar-seccion donde dimos click
            //obtener la sección
            //-const seccion = document.querySelector(`#paso-${pagina}`);
            //-seccion.classList.add('mostrar-seccion');

            // Eliminar la clase de actual en el tab anterior
            // document.querySelector('.tabs button.actual').classList.remove('actual'); //opcion 1
            //- document.querySelector('.tabs .actual').classList.remove('actual'); //opcion 2


            // Agregar la clase actual en el nuevo tab
            //-const tab = document.querySelector(`[data-paso="${pagina}"]`); //se usan corchetes porque es una propiedad y no una clase
            //-tab.classList.add('actual'); 

            // SE AGREGA EN EL PASO 11
            mostrarSeccion();
            botonesPaginador();
        })
    })
}


//function consultarDB(){
//    console.log('Consultando...');
//}

async function mostrarServicios(){
    try{
        const resultado = await fetch('./servicios.json');
        // console.log(resultado);

        const db = await resultado.json();
        
        //console.log(db);
        //console.log(db.servicios);
        
        //const servicios = db.servicios;
        //console.log(servicios);

        //Deestructuring
        const { servicios } = db;
        //console.log(servicios);

        // Generar el HTML
        servicios.forEach(servicio => {
            // console.log(servicio );
            const {id, nombre, precio } = servicio;
            //DOM Scripting
            // Generar nombre de servicio
            const nombreServicio = document.createElement('P');
            nombreServicio.textContent = nombre;
            nombreServicio.classList.add('nombre-servicio');
            //console.log(nombreServicio);

            // Generar el precio del servicio
            const precioServicio = document.createElement('P');
            precioServicio.textContent = `$ ${precio}`;
            precioServicio.classList.add('precio-servicio');
            //console.log(precioServicio);

            // Generar div contenedor de servicio
            const servicioDiv = document.createElement('DIV');
            servicioDiv.classList.add('servicio');

            //agregar cuando se modifica el javascript para el click de servicio
            //despues de probarl el onclick de seleccionarServicio
            servicioDiv.dataset.idServicio = id; //una vez agregado, mostrar la consola a dar click

            // Inyectar precio y nombre al div de servicio
            servicioDiv.appendChild(nombreServicio);
            servicioDiv.appendChild(precioServicio);
            //console.log(servicioDiv);

            // Selecciona un servicio para la cita
            servicioDiv.onclick = seleccionarServicio; //eventHandler porque es un nuevo elemento
                                                       // los eventListener se usan sobre elementos ya creados
              

            // Inyectar el div de servicio en el HTML
            document.querySelector('#servicios').appendChild(servicioDiv);
            

        });
    }catch (error){
        console.log(error);
    }
}

function seleccionarServicio(e){
    //console.log('click en servicio');
    //console.log(e.target); //checar en la consola que se emiten eventos en el div, parrafo, etc
                           // los eventos se propagan a los hijos 

    //const id = e.target.dataset.idServicio; //checar en la consola que se emiten eventos en el div, parrafo, etc
    //console.log(id);    

    //console.log(e.target.tagName); //checar en la consola que se emiten eventos en el div, parrafo, etc

    // agregar despues de usar el if
    let elemento;

    // Forzar que el elemento al cual le damos click sea el DIV
    if (e.target.tagName === 'P'){
        // console.log('Click en el párrafo');
        //console.log(e.target.parentElement);
        // agregar despues de usar el if
        elemento =  e.target.parentElement;
    } else {
        //console.log('Click en el DIV');
        elemento = e.target;
    }

    //console.log(elemento.dataset.idServicio);
    //elemento.classList.add('seleccionado');

    if(elemento.classList.contains('seleccionado')){
        elemento.classList.remove('seleccionado');

        //Se agrega la siguiente función en la sección 14

        //console.log(elemento.dataset.idServicio);

        const id = parseInt(elemento.dataset.idServicio);

        eliminarServicio(id);
    }
    else {
        elemento.classList.add('seleccionado');
        //Se agrega la siguiente función en la sección 14

            //identificamos el servicio del que se trata
        //console.log(elemento.dataset.idServicio);
        // console.log(elemento);
        // console.log(elemento.firstElementChild.textContent); // traversing the dom
        // console.log(elemento.secondElementChild.textContent); // no funciona, explicar por qué
        // console.log(elemento.firstElementChild.nextElementSibling.textContent); // traversing the dom
            //ahora se debe crear un objeto para almacenar el servicio
        const servicioObj = {
            id: parseInt(elemento.dataset.idServicio),
            nombre: elemento.firstElementChild.textContent,
            precio: elemento.firstElementChild.nextElementSibling.textContent
        }

        // console.log(servicioObj); //esta es la prueba final

         

        agregarServicio(servicioObj);
    }
    

}

//Se agrega la siguiente función en la sección 14
function eliminarServicio(id) {
    //console.log("Eliminando...", id);

    const { servicios } = cita;

    cita.servicios = servicios.filter( servicio => servicio.id !== id );

    console.log(cita);
}

//Se agrega la siguiente función en la sección 14
function agregarServicio(servicioObj) {
    //console.log("Agregando");

    const {servicios} = cita; // es el arreglo que esta definido en la variable global cita

    cita.servicios = [...servicios, servicioObj]; // se toma una copia de los servicios y se agrega el servicio seleccionado

    // probamos 
    console.log(cita);
}

function paginaSiguiente(){
    // console.log('siguiente');
    const paginaSiguiente = document.querySelector('#siguiente');
    paginaSiguiente.addEventListener('click', () => {
        pagina++;

        //console.log(pagina);

        // volver a comprobar los botones del paginador, sino, el botón anterior o siguiente no apareceran
        botonesPaginador();
    })
}

function paginaAnterior(){
    // console.log('anterior');
    const paginaAnterior = document.querySelector('#anterior');
    paginaAnterior.addEventListener('click', () => {
        pagina--;

        //console.log(pagina);

        botonesPaginador();
    })
}

function botonesPaginador () {
    const paginaSiguiente = document.querySelector('#siguiente');
    const paginaAnterior = document.querySelector('#anterior');
    console.log(pagina);
    if (pagina === 1){
        // console.log('El botón de anterior no se debe mostrar');
        paginaAnterior.classList.add('ocultar');
        paginaSiguiente.classList.remove('ocultar');
    } else if (pagina === 2 ){
        paginaAnterior.classList.remove('ocultar');
        paginaSiguiente.classList.remove('ocultar');
    } else if (pagina === 3) {
        paginaSiguiente.classList.add('ocultar');
        paginaAnterior.classList.remove('ocultar');
        // se agregó en la seccion 20
        mostrarResumen();
    }

    mostrarSeccion(); // Cambia la sección que se muestra por la de la página

}

function mostrarResumen(){
    //console.log(cita);
    
    // Destructuring
    const { nombre, fecha, hora, servicios } = cita;

    // Seleccionar el div de resumen
    const resumenDiv = document.querySelector('.contenido-resumen'); //hay que agregar al div la clase contenido-resumen 

    // Se agrega en la seccion 20
    // Limpia el HTML previo
    // resumenDiv.innerHTML = ''; // funciona pero esta mal hecho

    while (resumenDiv.firstChild) { // mientas resumenDiv tenga html en el, este while se estará ejecutando
        resumenDiv.removeChild(resumenDiv.firstChild);
    }

    // validación de objetos
    // console.log(Object.values(cita));
    if (Object.values(cita).includes('')){
        // console.log('El objeto esta vacío');
        const noServicios = document.createElement('P');


        noServicios.textContent = 'Faltan datos de servicios, hora, fecha o nombre';

        noServicios.classList.add('invalidar-cita');
        
        // agregaer a resumen Div
        resumenDiv.appendChild(noServicios);

        // Se agrega en la seccion 20
        return; // Si usamos el return ya no usamos el else
    } 
    // Se agrega en la seccion 20
    /*else {
        console.log("Todo bien, vamos a mostrar el resumen");
    }*/
        
        // Se agrega en la seccion 20 hasta el final de la función
        console.log("Todo bien, vamos a mostrar el resumenn");

        //Mostrar el resumen

        // Se agrega en la sección 21
        // Creamos el heading que se será el texto que muestra titulo para los datos de la cita
        const headingCita = document.createElement('H3');
        headingCita.textContent = 'Resumen de Cita';

        //nombre
        const nombreCita = document.createElement("P");
        //nombreCita.textContent = `<span>Nombre:</span> ${nombre}`;
        nombreCita.innerHTML = `<span>Nombre:</span> ${nombre}`;
        
        //fecha
        const fechaCita = document.createElement("P");
        fechaCita.innerHTML = `<span>Fecha:</span> ${fecha}`;
        //hora
        const horaCita = document.createElement("P");
        horaCita.innerHTML = `<span>Hora:</span> ${hora}`;
        

        // Se agrega en la seccion 21

        const serviciosCita = document.createElement('DIV');
        serviciosCita.classList.add('resumen-servicios');

        // Creamos el heading que se será el texto que separa la seccion de servicios en el resumen
        const headingServicios = document.createElement('H3');
        headingServicios.textContent = 'Resumen de Servicios';

        // agregamos el heading
        serviciosCita.appendChild(headingServicios);

        // Se agrega en la sección 22
        // variable que acumula el precio de los servicios
        let cantidad = 0;

        // Iterar sobre el arreglo de los servicios
        servicios.forEach (servicio => {

            // aplicamos destructuring
            const { nombre, precio } = servicio;

            // cada servicio va a estar en un div
            const contenedorServicio = document.createElement('DIV');
            contenedorServicio.classList.add('contenedor-servicio');

            // ahora si reunimos los datos de los servicios

            // nombre 
            const textoServicio = document.createElement('P');
            // textoServicio.textContent = servicio.nombre; // sin usar destructuring
            textoServicio.textContent = nombre; // aplicando destructuring

            // precio
            const precioServicio = document.createElement('P');
            precioServicio.textContent = precio; // aplicando destructuring
            precioServicio.classList.add('precio');

            // Se agrega en la sección 22
            // console.log('precio'); // me muestra los servicios tiene espacio y simbolo de dolar
            // quitando los espacios
            const totalServicio = precio.split('$');
            // console.log(totalServicio);
            // console.log(parseInt(totalServicio[1].trim()));
            cantidad += parseInt(totalServicio[1].trim());



            //probamos en la consola
            // console.log(textoServicio);
            // console.log(precioServicio);

            contenedorServicio.appendChild(textoServicio);
            contenedorServicio.appendChild(precioServicio);

            // agregamos al div creado fuera del forEach
            serviciosCita.appendChild(contenedorServicio); // casi al final de esta función se agregará al contenedor del resumen
        });

        // Se agrega en la sección 22
        console.log(cantidad);
        
        //agregamos los elementos HTML

        resumenDiv.appendChild(headingCita);

        resumenDiv.appendChild(nombreCita);
        resumenDiv.appendChild(fechaCita);
        resumenDiv.appendChild(horaCita)

        // Se agrega en la sección 21
        resumenDiv.appendChild(serviciosCita);
        //console.log(nombreCita);

        // Se agrega en las sección 22
        const cantidadPagar = document.createElement('P');
        cantidadPagar.classList.add('total');
        cantidadPagar.innerHTML = `<span>Total a pagar: </span> $ ${cantidad}`;
        
        resumenDiv.appendChild(cantidadPagar);
}

// Se agrega en la sección 15
function nombreCita(){
    // el elemento de html ya tiene un id=nombre
    const nombreInput = document.querySelector('#nombre');

    nombreInput.addEventListener('input', e => { //en lugar de input tambien mostrar el uso de change
        // console.log('escribiendo'); // nos interesa lo que el usuario escribe por lo que agregamos una e a los parentesis del arrow
        // console.log(e.target.value); // con esto sabemos lo que el usuario esta escribiendo

        const nombreTexto =  e.target.value.trim(); // con trim se quitan los espacios en blanco
                                                  // tambien hay trimStart() trimEnd().  
        console.log(nombreTexto);

        // Validación de nombreTexto debe tener algo
        if ( nombreTexto === '' || nombreTexto.length < 3){
            // console.log('Nombre no válido');
            mostrarAlerta('Nombre no válido', 'error');
        }
        else {
            // console.log('Nombre válido')

            const alerta = document.querySelector('.alerta');
            if(alerta){
                alerta.remove();
            }

            cita.nombre = nombreTexto;

            //console.log(cita);

        }


    })
}

// Se agrega en la sección 16
function mostrarAlerta(mensaje, tipo){
    // console.log('El mensaje es ', mensaje);

    // Si hay una alerta previa, no crear otra
    const alertaPrevia = document.querySelector('.alerta');

    if (alertaPrevia) {
        // alertaPrevia.remove(); // es la opción 1
        return; // opcion 2 con mejor rendimiento
    }

    const alerta = document.createElement('DIV');
    alerta.textContent = mensaje;
    alerta.classList.add('alerta');

    if (tipo === 'error') {
        alerta.classList.add('error');
    }

    // console.log(alerta);

    // Insertar en el HTML
    const formulario = document.querySelector('.formulario');
    formulario.appendChild( alerta  );

    // Eliminar la alerta después de 3 segundos
        // setTimeout, espera una cantidad de tiempo y ejecuta la función
        // setInterval, espera ese intervalo de tiempo y ejecuta la función varias veces mientras se cumpla

        setTimeout(() => {
            alerta.remove();
        } , 3000);
}


// Se agrega en la sección 17
function fechaCita(){
    const fechaInput = document.querySelector('#fecha');

    fechaInput.addEventListener('input', e => {
        // console.log(e.target.value); // regresa un String de la fecha que se seleccionó

        // para convertir el String a fecha
        const dia = new Date(e.target.value).getUTCDay(); //domingo es 0, lunes es 1, martes es 2 y así ...

        if ([0,6].includes(dia)){ // [0] es un arreglo porque eso nos permitiría poner algun otro día [0, 6], domingos y sabados
           // console.log('Seleccionaste domingo, lo cual no es válido');
           e.preventDefault();
           fechaInput.value = ''; // resetea el valor de la fecha 
           mostrarAlerta('Fines de semana no son permitidos', 'error');
        } else {
            // console.log('Día válido');
            cita.fecha = fechaInput.value;

            console.log(cita);
        }

        // console.log(dia);
        // console.log(dia.toLocaleDateString('es-ES', opciones));
    })
}

function deshabilitarFechaAnterior(){
    const inputFecha = document.querySelector("#fecha");

    const fechaAhora = new Date(); //toma la fecha y hora del momento en el que se creó
    const year = fechaAhora.getFullYear();
    const mes = (fechaAhora.getMonth() + 1).toString().padStart(2, "0"); //para que simepre regrese dos digitos
    //(dt.getMonth() + 1).toString().padStart(2, "0");
    const dia = (fechaAhora.getDate() + 1).toString().padStart(2, "0");  // se le suma uno para evitar las reservaciones en el mismo día


    // Formato deseado: AAAA-MM-DD

    const fechaDeshabilitar = `${year}-${mes}-${dia}`;

     /* console.log(fechaAhora); 
    console.log(fechaAhora.getFullYear());
    console.log(fechaAhora.getDate());  
    console.log(fechaAhora.getMonth()); // los meses en JavaScript inician desde le día cero 
    */

    //console.log(fechaDeshabilitar);
    inputFecha.min = fechaDeshabilitar;// El mismo nombre que tengan los atributos es como los podras acceder en JavaScript
    //console.log(inputFecha);
    
}

function horaCita(){
    const inputHora = document.querySelector("#hora");
    inputHora.addEventListener('input', e => {
        // console.log(e.target.value);
        const horaCita = e.target.value;
        const hora = horaCita.split(':'); // regresa un arreglo, en la posición 0 estará la hora y en la posición 1 estaran los minutos.
        // console.log(hora);
        //validar las horas
        if(hora[0] < 10 || hora[0] > 18){
            // console.log("Horas no válidas");
            mostrarAlerta('Hora no válida', 'error')
            setTimeout(() => {
                inputHora.value = "";
            }, 3000);
            
        } else {
            // console.log("Hora válida");
            cita.hora = horaCita;

            console.log(cita);

        }
    });
}  