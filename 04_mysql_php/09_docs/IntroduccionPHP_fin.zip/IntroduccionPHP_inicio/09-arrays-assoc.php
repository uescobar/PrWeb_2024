<?php include 'includes/header.php';

// los arreglos asociativos son el equivalente a los objetos en javascript, es decir,
// se accede al elemento a traves de la propiedad

$cliente = [
    'nombre' => 'Armando',
    'saldo' => 200,
    'informacion' => [
        'tipo' => 'premium',
        'disponible' => 100
    ]
];

// accediendo a todo el array
echo "<pre>";
var_dump($cliente);
echo "</pre>";

// accediendo a una propiedad
echo "<br/>";
echo $cliente['nombre'];
echo "<br/>";
echo $cliente['saldo'];
echo "<br/>";
echo $cliente['informacion']['tipo'];
echo "<br/>";

// agrregando propiedades al array

$cliente['codigo'] = 51651165;

echo "<pre>";
var_dump($cliente);
echo "</pre>";

include 'includes/footer.php';