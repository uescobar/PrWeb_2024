<?php include 'includes/header.php';

$productos = [
    [
        'nombre' => 'Tablet',
        'precio' => 200,
        'disponible' => true
    ],
    [
        'nombre' => 'Television 20"',
        'precio' => 300,
        'disponible' => true
    ],
    [
        'nombre' => 'Monitor Curvo',
        'pecio' => 400,
        'disponible' => false
    ]
];

// foreach( $productos as $producto):
//     echo "<pre>";
//     var_dump($producto);
//     echo "</pre>";
// endforeach;

// foreach($productos as $producto){ 
//     echo "<li>";
//     echo "Titulo de producto";
//     echo "</li>";
// }

foreach($productos as $producto){ ?> <!-- Termina el código de PHP y comienza código de html-->
    <li>
        <p> Producto: <?php echo $producto['nombre'];  ?></p> <!-- abrimos y cerramos php para mezclar código -->
        <p> Precio: <?php echo "$ " . $producto['precio']; ?></p>
        <!-- <?php
            // if($producto['disponible']){
            //     echo "<p>Disponible</p>";
            // } else{
            //     echo "<p>No disponible</p>";
            // }
        ?> -->

        <p><?php echo ($producto['disponible']) ? 'Disponible' : 'No disponible'; ?> </p>
    </li>

    <?php //termina código de HTML y comienza código de PHP con el fin de usar de mejor manera el navegador y el servidor

    // echo "<pre>";
    // var_dump($producto);
    // echo "</pre>";
}



include 'includes/footer.php';