<?php include 'includes/header.php';

//incrementos
$numero1 = 30;
$numero1++;

echo $numero1; //ejecutar el archivo

$numero1++;

echo $numero1; //ejecutar el archivo

//decrementos

$numero2 = 30;
$numero2--;

echo $numero2; //ejecutar el archivo

echo --$numero2;

// incrementos de cierta cantidad
$numero1+=5; // incremento de 5 unidades



include 'includes/footer.php';