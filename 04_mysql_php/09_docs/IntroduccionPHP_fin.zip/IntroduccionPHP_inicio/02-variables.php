<?php include 'includes/header.php';

$nombre = "Armando";

//$_nombre = "Armando";
//$nombre_ = "Armando";

echo $nombre;

var_dump($nombre); // imprime más información de la variable

// variables de tipo const (se comportan como const en javascript)
define('constante', "este es el valor de la constante");
echo constante; // se impime sin el signo de dolar

const constante2 = "Hola2"; // no es tan común
echo constante2;

$nombreCliente = "Ures";
$nombre_cliente = "Ures";

include 'includes/footer.php';