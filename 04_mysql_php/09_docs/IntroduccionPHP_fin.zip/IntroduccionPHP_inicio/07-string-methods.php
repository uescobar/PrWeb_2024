<?php include 'includes/header.php';

$nombreCliente = "Edgar Pérez";
//conocer extensión del string 
echo strlen($nombreCliente);
echo "<br/>";
var_dump($nombreCliente);
echo "<br/>";

$nombreCliente = "              Edgar Pérez";

//eliminar espacios en blanco
echo trim($nombreCliente);
echo "<br/>";
echo strlen($nombreCliente);

// Convertirlo a mayúsculas
echo "<br/>";
echo strtoupper($nombreCliente);
echo "<br/>";
echo strtolower($nombreCliente);

$mail1 = "correo@correo.com";
$mail2 = "Correo@correo.com";

//comparando los correos
//var_dump($mail1 === $mail2); //resultado es false

var_dump(strtolower($mail1) === strtolower($mail2)); //resultado es false

//reemplazar una letra
$nombreCliente = "Edgar Pérez";
echo "<br/>";

//echo str_replace('Edgar', 'E', $nombreCliente); // reemplaza la palabra por la letra E

//revisar si un string existe o no
echo "<br/>";
echo strpos($nombreCliente, 'Edgar'); //muestra el valor del índice en donde aparece la cadena, sino existe, no se imprime nada

// concatenar 

$tipoCliente = "Premium";

echo "<br/>";
echo "El cliente " . $nombreCliente . " es " . $tipoCliente;
echo "<br/>";
echo "El cliente " . $nombreCliente . $tipoCliente;

echo "<br/>";

echo "El cliente {$nombreCliente} es ${tipoCliente}";

include 'includes/footer.php';