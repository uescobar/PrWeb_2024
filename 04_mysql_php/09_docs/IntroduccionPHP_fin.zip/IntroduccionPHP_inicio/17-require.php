<?php require 'includes/header.php'; //puede ir con parantesis o no include ('includes/header.php')


// En PHP8 se agregaron los parámetros nombrados
// function sumar(int $numero1 = 0, int $numero2 = 0){
//     echo $numero1 + $numero2;
// }

// sumar(numero2: 10, numero1:20);


// require se usa cuando se tienen funciones que son criticas y deseamos que si hay error, la ejecución se detenga

// include, se usa para cuando no es muy importante detener la aplicación podría seguir funcionando


//require_once, si ya fue incluido, lo ignora, sino fue incluido lo incluye

require 'funciones.php';

iniciarApp();


include 'includes/footer.php';