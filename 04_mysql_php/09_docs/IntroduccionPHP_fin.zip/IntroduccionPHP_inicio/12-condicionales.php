<?php include 'includes/header.php';

$autenticado = true;


if($autenticado){
    echo "Usuario autenticado correctamente";
} else {
    echo "Usuario no autenticado, inicia sesión";  
}


$admin = false;

if($autenticado || $admin){
    echo "Usuario autenticado correctamente";
} else {
    echo "Usuario no autenticado, inicia sesión";  
}

$admin = false;

if($autenticado && $admin){
    echo "Usuario autenticado correctamente";
} else {
    echo "Usuario no autenticado, inicia sesión";  
}

// if anidados

$cliente = [
    'nombre' => 'Pedro',
    'saldo' => 200,
    'informacion' => [
        'tipo' => 'Premium'
    ]
];

echo "<br/>";

if( !empty($cliente)){
    echo "El arreglo de cliente esta vacio";
    
    if ($cliente['saldo'] > 0 ){
        echo "<br/>";
        echo "El saldo del cliente está disponible";
    } else {
        echo "No hay saldo";
    }

} else {
    echo "El arreglo de cliente no esta vacío";
}

// elseif
if($cliente['saldo'] > 0){
    echo "El cliente tiene saldo";
} else if ($cliente['informacion']['tipo'] === 'Premium'){
    echo "El cliente es premium";
} else {
    echo "No hay cliente definido o no tiene sasldo o no es premium";
}

// switch
echo "<br/>";
$tecnologia = 'PHP';
switch($tecnologia){
    case 'PHP':
        echo "PHP, un excelente lenguaje";
        break;
    case 'JavaScript':
        echo 'Genial,e l lenguaje de la web';
        break;
    case 'HTML':
        echo "Genial";
        break;

    default: 
        echo "Agun lenguaje que no sé cual es";
        break;
}

include 'includes/footer.php';