<?php include 'includes/header.php';

$productos = [
    [
        'nombre' => 'Tablet',
        'precio' => 200,
        'disponible' => true
    ],
    [
        'nombre' => 'Television 20"',
        'precio' => 300,
        'disponible' => true
    ],
    [
        'nombre' => 'Monitor Curvo',
        'pecio' => 400,
        'disponible' => false
    ]
];

// el desarrollador define cómo se quiere que se entreguen los resultados desde la base de datos

echo "<pre>";
var_dump($productos);

// El arreglo no se puede leer directamente en javascript, se tiene que convertir en JSON
// $json = json_encode($productos);
$json = json_encode($productos, JSON_UNESCAPED_UNICODE);

$json_array = json_decode($json);

var_dump($json);

var_dump(($json_array));

echo "</pre>";




include 'includes/footer.php';