<?php


function iniciarApp(){
    echo "Iniciando nuestra App...";
}