<?php include 'includes/header.php'; ?>

<?php echo "Hola mundo"; ?>

<br>

<?php echo ("Hola mundo");

print("Hola mundo");

print "Hola mundo";

/*cuando se trabaja con arreglos se estila y se usa para debugguear */
print_r("Hola mundo");

/*Se utiliza mucho cuando se esta debuggueando el codigo*/
/* Da informacion extra, además del contenido de la variable */
var_dump("Hola mundo");


include 'includes/footer.php'; ?>