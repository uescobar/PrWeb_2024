<?php 

declare(strict_types=1);
include 'includes/header.php';

// function sumar(){
//     echo 2 + 2;
// }

// sumar();
// sumar();
// sumar();
// sumar();

// function sumar($numero1, $numero2){
//     echo $numero1 + $numero2;
// }

// sumar(10,20);
// echo "<br>";

// function sumar($numero1 = 0, $numero2 = 0){
//     echo $numero1 + $numero2;
// }

// sumar(10);
// echo "<br>";



function sumar(int $numero1 = 0, int $numero2 = 0){
    echo $numero1 + $numero2;
}

sumar(10, 1);
echo "<br>";


include 'includes/footer.php';