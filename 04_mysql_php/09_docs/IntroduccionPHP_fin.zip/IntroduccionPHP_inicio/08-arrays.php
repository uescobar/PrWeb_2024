<?php include 'includes/header.php';

// los resultados a una consulta a la base de datos se almacenan en un arreglo

// cuando se autentica un usuario, sus datos se almacenan en un arreglo que se conoce como sesión

// Los arreglos indexados
$carrito = ['Tablet', 'Television', 'Computadora'];
# $carrito = array(); // otra forma de hacerlo


// echo "<pre>";
// var_dump($carrito);
// echo "</pre>";

// util para ver los contenidos de un array
echo "<pre>";
var_dump($carrito[1]);
echo "</pre>";

// acceder a un elemento del array 
echo $carrito[1];

//agregar un nuevo elemento en el índice 3 del arreglo
$carrito[3] = 'Nuevo producto';

// añadir nuevo elemento al final del arreglo
array_push($carrito, 'Audifonos');

// añadir al inicio
array_unshift($carrito, 'Smartwatch');


// util para ver los contenidos de un array
echo "<pre>";
var_dump($carrito);
echo "</pre>";

// otra forma de crear el arreglo
$clientes = array('Cliente 1', 'Cliente 2', 'Cliente 3');
// util para ver los contenidos de un array
echo "<pre>";
var_dump($clientes);
echo "</pre>";

echo $clientes[1];

include 'includes/footer.php';