<?php include 'includes/header.php';

// while

$i = 0; // contador

while($i < 10){
    echo $i . "<br>";
    $i++; //incremento
}

// otra sintaxis
while($i < 10):
    echo $i . "<br>";
    $i++; //incremento
endwhile;

// do while
$i = 0;

echo "<br>";

do {
    echo $i . "<br>";
    $i++;

} while ($i < 10);

echo "<br>";

// for loop
for($i=0; $i < 10; $i++){
    echo $i."<br>";
}

echo "<br>";

/*
    * 3 imprimir Fizz
    * 5 imprimir Buzz
    * 3 y 5 imprimir FIZZ BUZZ
*/ 

for ($i = 1; $i < 1000; $i++) {
    if($i % 15 === 0) {
        echo $i . "  - FIZZBUZZ <br/>";
    } else if($i % 3 === 0){
        echo $i . "  - Fizz <br/>";
    } else if ($i % 5 === 0){
        echo $i . "  - Buzz <br/>";
    } else {
        echo $i . "<br>";
    }
}

//otra sintaxis
for ($i = 1; $i < 1000; $i++):
    if($i % 15 === 0):
        echo $i . "  - FIZZBUZZ <br/>";
    elseif($i % 3 === 0):
        echo $i . "  - Fizz <br/>";
    elseif ($i % 5 === 0):
        echo $i . "  - Buzz <br/>"; 
    else:
        echo $i . "<br>";
    endif;
endfor;

// For each

$clientes = array('Pedro', 'Juan', 'Karen');

foreach ($clientes as $cliente) {
    echo $cliente . '<br>';
}

echo count($clientes);

echo sizeof(($clientes));

for ($i=0; $i < count($clientes); $i++) {
    echo $clientes[$i] . '<br>';
}


// For each con arreglo asociativo, por defecto se realiza sobre los valores, no sobre las llaves del objeto

$cliente= [
    'nombre' => 'Juan',
    'saldo' => 200,
    'tipo' => 'Premium'
];

foreach( $cliente as $key => $valor): // para iterar sobre llave y valor al mismo tiempo 
    echo $key . " --- " . $valor . '<br>';
endforeach;

include 'includes/footer.php';