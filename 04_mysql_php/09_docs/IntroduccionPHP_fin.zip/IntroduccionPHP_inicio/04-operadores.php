<?php include 'includes/header.php';


$numero1 = 20;
$numero2 = 10;

//sumar
echo $numero1 + $numero2;
echo "<br>";
//resta
echo $numero1 - $numero2;

echo "<br>";

//mutiplicar
echo $numero1 * $numero2;
echo "<br>";
//dividir
echo $numero1 / $numero2;
echo "<br>";
// multiplicar cierta cantidad de veces
echo 2**3;

include 'includes/footer.php';