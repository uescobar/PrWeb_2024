<?php 
//segundo momento
declare(strict_types=1);
include 'includes/header.php';

// primer momento
// function usuarioAutenticado(){
//     return "El usuario está autenticado";
// }

//segundo momento
// function usuarioAutenticado() : string { // da error porque se estan estableciendo tipos estrictos
//     return true;
// }

//tercer momento
// function usuarioAutenticado(bool $autenticado) : string {
//     if($autenticado){
//         return "El usuario está autenticado";    
//     } else {
//         return "No autenticado";
//     }
    
// }

//cuarto momento
// function usuarioAutenticado(bool $autenticado) : void { //array string booblean float int
//     if($autenticado){
//         echo "El usuario está autenticado";    
//     } else {
//         echo "No autenticado";
//     }
    
// }

// quinto momento
// function usuarioAutenticado(bool $autenticado) : ?string { //es opcional que regrese un string PHP7
//     if($autenticado){
//         echo "El usuario está autenticado";    
//     } else {
//         echo null;
//     }
    
// }

// sexto momento
function usuarioAutenticado(bool $autenticado) : string|int { //regresa string o int PHP8, se le conoce como uniones
    if($autenticado){
        echo "El usuario está autenticado";    
    } else {
        echo 20;
    }
    
}


$usuario = usuarioAutenticado(false);


echo $usuario;


include 'includes/footer.php';