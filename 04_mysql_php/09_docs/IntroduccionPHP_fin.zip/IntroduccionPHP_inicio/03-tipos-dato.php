<?php include 'includes/header.php';

// boolean
$logueado = true;
var_dump($logueado);

// enteros
$numero = 200;
var_dump($numero);

// floats
$float = 200.5;
var_dump($float);

// strings
$nombre = "Armando"; // pueden ser comillas dobles o sencillas
var_dump($nombre);

//arreglos
$array = [];
var_dump($array);


include 'includes/footer.php';