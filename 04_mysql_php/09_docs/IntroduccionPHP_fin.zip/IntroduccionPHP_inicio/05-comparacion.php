<?php include 'includes/header.php';

$numero1 = 20;
$numero2 = 30;
$numero3 = 30;
$numero4 = "30";

var_dump($numero1 > $numero2);
echo "<br/>";
var_dump($numero1 < $numero2);
echo "<br/>";
var_dump($numero1 >= $numero2);
echo "<br/>";
var_dump($numero1 <= $numero2);
echo "<br/>";
var_dump($numero2 == $numero3);
echo "<br/>";
var_dump($numero2 == $numero4);
echo "<br/>";
var_dump($numero2 === $numero4);

//operador que compara si 
// el de la izquierda es menor que el de la derecha, da -1
// el de la izquierda es igual al de la derecha, da 0
// el de la izquierada es mayor al de la derecha, da 1
echo "<br/>";
var_dump($numero1 <=> $numero2); // -1
echo "<br/>";
var_dump($numero2 <=> $numero3); // 0
echo "<br/>";
var_dump($numero2 <=> $numero1); // 1


include 'includes/footer.php';